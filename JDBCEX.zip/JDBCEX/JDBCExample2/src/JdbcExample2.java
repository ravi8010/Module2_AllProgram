import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcExample2 {
public static void main(String[] args) throws SQLException, ClassNotFoundException {
	
	Class.forName("oracle.jdbc.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
	    PreparedStatement stmt=con.prepareStatement("insert into employee10 values(?,?,?,?,?)");
	    Scanner sc=new Scanner(System.in);
	do
	{
		System.out.println("Enter name ");
		String name=sc.nextLine();
		System.out.println("Enter City ");
		String city=sc.nextLine();
		System.out.println("Enter Country ");
		String cntry=sc.nextLine();
		System.out.println("Enter Qualification ");
		String qly=sc.nextLine();
		System.out.println("enter salary ");
		int slry=sc.nextInt();
		stmt.setString(1, name);
		stmt.setString(2, city);
		stmt.setString(3, cntry);
		stmt.setString(4, qly);
		stmt.setInt(5,slry);
		int i=stmt.executeUpdate();
		System.out.println("Record is inserted");
		System.out.println("Do you want to continue: y/n");
		char ch=sc.next().charAt(0);
		if(ch=='n')
		{
			break;
		}
		
	}
	while(true);
	con.close();
	
	
	
}
}
