
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class JdbcExamples {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	    
		
		
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
			//Statement stmt=con.reateStatement();
			PreparedStatement stmt1=con.prepareStatement("insert into employee10 values(?,?,?,?,?)");
			stmt1.setString(1,"Ravi");//1 specifies the first parameter in the query  
			stmt1.setString(2,"Agra");
			stmt1.setString(3,"India");//1 specifies the first parameter in the query  
			stmt1.setString(4,"Phd");
			stmt1.setInt(5,2000);
			int i=stmt1.executeUpdate();  
			System.out.println(i+" records inserted");
			
			
			//String query="update employee10 set name='Ravi' where salary=3000";
			//String query="insert into employee10 values('ravi','abc','cde','ghi',2000)";
//	String query="delete from employee10 where name='ravi'";
			/*String query1="  declare "
					+ "a number;"
					+ "b number;"
					+ "begin"
					+ "a:=10;"
					+ "b:=20;"
					+ "dbms_output.put_line(a+b); "
					+ "end;"
					+ " ";*/
			
			/*ResultSet rs1=stmt.executeQuery(query1);
			while(rs.next())
			{
				System.out.println(rs.getString(1)+" "+rs.getString(2));
				
			}*/
			
			//System.out.println(rs1);
			//ResultSet rs=stmt.executeQuery("select * from employee10");
			
			PreparedStatement stmt2=con.prepareStatement("select * from employee10");
			ResultSet rs=stmt2.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));
				
			}

		   

			con.close();
		
		
		
	
	}
}
