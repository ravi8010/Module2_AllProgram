import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Employee emp=(Employee)ctx.getBean("emp");
		System.out.println("EmployeeName:"+emp.getName());
		System.out.println("EmployeeNo:"+emp.getEmpno());
		
		

	}

}
