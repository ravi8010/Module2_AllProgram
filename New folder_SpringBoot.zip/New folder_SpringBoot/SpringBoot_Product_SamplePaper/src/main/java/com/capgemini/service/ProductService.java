
package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.Product;

public interface ProductService {
	
	public Product create(Product product);
	public Product updateProduct(Product product);
	public Product deleteProduct(int id);
    public List<Product> viewProduct();
    public Product findProdut(int id);

}
