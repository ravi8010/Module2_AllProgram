package com.capgemini.repo;

import java.util.List;

import com.capgemini.beans.Product;

public interface ProductDao {
	public Product create(Product product);
	public Product updateProduct(Product product);
	public Product deleteProduct(int id);
    public List<Product> viewProduct();
    public List findProdut(int id);
    

}
