package com.capgemini.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.beans.Product;
@Transactional
@Repository
public class ProductDaoImpl implements ProductDao {
    @PersistenceContext
    @Autowired
    EntityManager entityManager;
    
    
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Product create(Product product) {
		
		entityManager.persist(product);
		entityManager.flush();
		return product;
		
	}

	@Override
	public Product updateProduct(Product product) {
		entityManager.merge(product);
		return product;
	
	}

	@Override
	public Product deleteProduct(int id) {
		Product product=entityManager.find(Product.class,id);
		entityManager.remove(product);
		return product;
	}

	@Override
	public List<Product> viewProduct() {
		Query query=entityManager.createNativeQuery("select * from product");
		List<Product> list=query.getResultList();
		return list;
	}

	@Override
	public List<Product> findProdut(int id) {
		Query query=entityManager.createNativeQuery("select * from product where id=?").setParameter(1, id);
		List<Product> list=query.getResultList();
		return list;
	}

}
