package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.beans.Product;
import com.capgemini.repo.ProductDao;
@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao pdao;
	
	
	
	@Override
	public Product create(Product product) {
		
		return null;
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product deleteProduct(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> viewProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product findProdut(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
