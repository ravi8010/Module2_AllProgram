package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.Student;

public interface StudentService {

	public Student addStudent(Student student);
	public Student updateStudent(Student student);

	public Student findStudent(int id);
	public Student deleteStudent(int id);
	public List<Student> getStudents();
	public List<Student> getStudentByName(String name);	
	
}
