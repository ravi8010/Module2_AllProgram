package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.beans.Student;
import com.capgemini.dao.IStudent;


@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	IStudent istudent;

	public IStudent getIstudent() {
		return istudent;
	}

	public void setIstudent(IStudent istudent) {
		this.istudent = istudent;
	}

	@Override
	public Student addStudent(Student student){
		
		if(istudent.findStudent(student.getId())!=null)
		{
			throw new RuntimeException();
		}
		return istudent.addStudent(student);

	}

	@Override
	public Student updateStudent(Student student) {
		return istudent.updateStudent(student);
	}

	@Override
	public Student findStudent(int id) {

		return istudent.findStudent(id);
	}

	@Override
	public Student deleteStudent(int id) {
		return istudent.deleteStudent(id);

	}

	@Override
	public List<Student> getStudents() {
		return istudent.getStudents();

	}

	@Override
	public List<Student> getStudentByName(String name) {
		return istudent.getStudentByName(name);

	}

}
