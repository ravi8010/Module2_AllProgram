package com.capgemini.application.SpringMVCdb.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.capgemini.application.SpringMVCdb.exception.DuplicatePhoneNo;

@ControllerAdvice
public class exceptionHandler {

	@ExceptionHandler(value=DuplicatePhoneNo.class)
	public ResponseEntity<Object> duplicate(DuplicatePhoneNo ex)
	{
		return new ResponseEntity<>("Exception DUPLICATE",HttpStatus.NOT_FOUND);
	}
}
