package com.capgemini.SpringMVC_1Prac;
 
@Controller
public class Controller {

}
