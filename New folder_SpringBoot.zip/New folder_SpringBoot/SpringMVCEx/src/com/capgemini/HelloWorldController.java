package com.capgemini;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class HelloWorldController {
	@RequestMapping("/hello")
	public String display(HttpServletRequest request,Model model)
	{
		String name=request.getParameter("name");
		String pas=request.getParameter("pass");
		if(pas.equals("12345"))
		{
			String msg="Hello "+name;
		    model.addAttribute("message", msg);
		    return "viewpage";
		}
		else 
		{
			String msg1="Sorry"+name+"or"+pas+"is not correct";
			model.addAttribute("message",msg1);
			return "errorpage";
		}
		
	}
	
	
}
