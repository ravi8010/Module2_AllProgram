package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.beans.Student;
import com.capgemini.dao.IStudent;
import com.capgemini.exception.DuplicateIdException;
import com.capgemini.exception.IDDoesNotExistException;
import com.capgemini.exception.ListEmptyException;


@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	IStudent istudent;

	public IStudent getIstudent() {
		return istudent;
	}

	public void setIstudent(IStudent istudent) {
		this.istudent = istudent;
	}

	@Override
	public Student addStudent(Student student){
		
		if(istudent.findStudent(student.getId())!=null)
		{
			throw new DuplicateIdException("duplicate id Exception");
		}
		return istudent.addStudent(student);

	}

	@Override
	public Student updateStudent(Student student) {
		return istudent.updateStudent(student);
	}

	@Override
	public Student findStudent(int id) {

		if(istudent.findStudent(id)==null)
		{
			throw new IDDoesNotExistException("Id is not Exist");
		}
		return istudent.findStudent(id);
	}

	@Override
	public Student deleteStudent(int id) {
		
		if(istudent.findStudent(id)==null)
		{
			throw new IDDoesNotExistException("");
		}
		return istudent.deleteStudent(id);

	}

	@Override
	public List<Student> getStudents() {
		if(istudent.getStudents().isEmpty())
		{
			throw new ListEmptyException("List is empty");
		}
		return istudent.getStudents();

	}

	@Override
	public List<Student> getStudentByName(String name) {
		return istudent.getStudentByName(name);

	}

}
