package com.capgemini.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.lang.NonNull;

@Entity
@Table(name="Student1")
public class Student
{
	@Id
private int id;
	@NotNull(message="name should not be null")
	@Pattern(regexp="[A-Z][a-z]+",message="Name should be Alphabetical and Starting with Capital Letter")
private String name;
	@NotNull(message="Mobile should not be null")
	@Pattern(regexp="(0/91)?[7-9][0-9]{9}",message="enter valid number")

private String mobileNo;
	@NotNull(message="Address should not be null")
	private String address;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public Student(int id, String name, String mobileNo, String address) {
	super();
	this.id = id;
	this.name = name;
	this.mobileNo = mobileNo;
	this.address = address;
}
@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + ", mobileNo=" + mobileNo + ", address=" + address + "]";
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}



}
