package com.capgemini.service;

import java.math.BigDecimal;
import java.util.Optional;

import com.capgemini.beans.Customer;

public interface WalletService {
public Customer createAccount(String name,String mobileNo,BigDecimal amount);
public Customer showAmount(String mobileNo);
public Customer depositAmount(String mobileNo,BigDecimal amount);
public Customer withdrawAmount(String mobileNo,BigDecimal amount);
public Optional<Customer> fundTransfer(String sourceMobileNo,String targetMobileNo,BigDecimal amount);

}
