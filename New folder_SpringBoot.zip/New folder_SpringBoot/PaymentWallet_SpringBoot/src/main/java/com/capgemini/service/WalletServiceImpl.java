package com.capgemini.service;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;
import com.capgemini.repo.WalletRepo;
@Service
public class WalletServiceImpl implements WalletService {
   
	@Autowired
	WalletRepo walletRepo;
   
	@Override
	public Customer createAccount(String name, String mobileNo, BigDecimal amount) {
		
		Wallet wallet=new Wallet(amount);
		Customer customer=new Customer();
		customer.setMobileNo(mobileNo);
		customer.setName(name);
		customer.setWallet(wallet);
	     return  walletRepo.save(customer);
		
	
	}

	@Override
	public Customer showAmount(String mobileNo) {
	 Customer customer= walletRepo.findById(mobileNo).get();
      return customer;	      
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		Customer customer=walletRepo.findById(mobileNo).get();
		Wallet wallet=customer.getWallet();
		wallet.setAmount(wallet.getAmount().add(amount));
		return customer;
	     
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		Customer customer=walletRepo.findById(mobileNo).get();
		Wallet wallet=customer.getWallet();
		wallet.setAmount(wallet.getAmount().subtract(amount));
		return customer;
	    
	}

	@Override
	public Optional<Customer> fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		this.depositAmount(targetMobileNo, amount);
		this.withdrawAmount(sourceMobileNo, amount);
		return walletRepo.findById(sourceMobileNo);
	}

}
