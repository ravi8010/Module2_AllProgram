package com.capgemini.controller;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.beans.Customer;
import com.capgemini.service.WalletServiceImpl;

@RestController
public class WalletController {

	@Autowired
	WalletServiceImpl walletServiceImpl;
	Customer customer;

	@RequestMapping(method = RequestMethod.GET, value = "/test")
	public String test() {
		return "hello";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/createAccount/{name}/{mobileNo}/{amount}")
	public Customer createAccount(@PathVariable String name, @PathVariable String mobileNo,
			@PathVariable String amount) {
		
		BigDecimal amount2=new BigDecimal(amount);
		return walletServiceImpl.createAccount(name, mobileNo, amount2);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/showBalance/{mobileNo}")
	public Customer showBalance(@PathVariable String mobileNo) {
		return walletServiceImpl.showAmount(mobileNo);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/deposit/{mboileNo}/{amount}")
	public Customer depositAmount(@PathVariable String mobileNo, @PathVariable BigDecimal amount) {
		return walletServiceImpl.depositAmount(mobileNo, amount);

	}

	@RequestMapping(method = RequestMethod.POST, value = "/withdraw/{mobileNo}/{amount}")
	public Customer withdraw(@PathVariable String mobileNo, @PathVariable BigDecimal amount) {
		return walletServiceImpl.withdrawAmount(mobileNo, amount);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/fundTransfer/{sMobileNo}/{tMobileNo}/{amount}")
	public Optional<Customer> fundTransfer(@PathVariable String sMobileNo, @PathVariable String tMobileNo,
			@PathVariable BigDecimal amount) {
		return walletServiceImpl.fundTransfer(sMobileNo, tMobileNo, amount);
	}
}
