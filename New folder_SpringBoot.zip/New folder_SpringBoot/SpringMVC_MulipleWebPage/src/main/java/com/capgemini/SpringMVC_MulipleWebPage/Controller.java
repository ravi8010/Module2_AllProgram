package com.capgemini.SpringMVC_MulipleWebPage;
@Controller
public class Controller {
	

}
