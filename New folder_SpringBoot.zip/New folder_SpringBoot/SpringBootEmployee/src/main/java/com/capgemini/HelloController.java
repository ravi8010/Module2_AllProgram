package com.capgemini;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController 
{
	@PostMapping("/hello method=post")
	public Employee getEmployee()
	{
		Employee emp=new Employee();
		emp.setId(12);
		emp.setName("ravi");
		return emp;
	}
	
}
