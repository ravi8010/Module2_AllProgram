package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartManagementRaviKumarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementRaviKumarApplication.class, args);
	}

}
