package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.beans.Employee;

@Repository
public class EmployeeDao {
	
	private List<Employee> employee = new ArrayList<>(Arrays.asList( 
			new Employee("100","Ravi","2000","Student"),
	        new Employee("101","Krishna","2000","Student"),
	        new Employee("102","Saurabh","3000","Teacher")
	  ));

public List<Employee> getAllEmployee()
{
	return employee; }

public Employee getEmployeeById(String id)
{
	for(Employee empl:employee)
	{
		if(empl.getId().equals(id))
			return empl;
	}
	return null;
}

public void addEmployee(Employee emp)
{
 employee.add(emp);	
}
public void updateEmployee(String id,Employee emp)
{
	
	for(int i=0;i<employee.size();i++)
	{
		
		Employee t =employee.get(i);
		if(t.getId().equals(id))
		{
			employee.set(i, emp);
			return;
		}
	}

}


public void deleteEmployee(String id)
{
employee.removeIf(employee->employee.getId().equals(id));	
}


}
