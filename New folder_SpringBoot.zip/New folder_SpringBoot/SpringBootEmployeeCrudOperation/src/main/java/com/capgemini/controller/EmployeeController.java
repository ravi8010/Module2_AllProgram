package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.beans.Employee;
import com.capgemini.dao.EmployeeDao;

@RestController
public class EmployeeController {
    @Autowired
	EmployeeDao employeeService;
	@RequestMapping("/employees")
	public List<Employee> getEmployees()
	{
		return employeeService.getAllEmployee();
	}
	@RequestMapping(method=RequestMethod.POST,value="/employee")
	public void addEmployee(@RequestBody Employee emp)
	{
		 employeeService.addEmployee(emp);
	}
	@RequestMapping(method=RequestMethod.PUT,value="/updateemployee/{id}")
     public void updateEmployee(@RequestBody Employee emp,@PathVariable String id)
     {
		employeeService.updateEmployee(id, emp);
     }
	@RequestMapping(method=RequestMethod.DELETE,value="/deleteemployee/{id}")
    public void delete(@RequestBody Employee emp,@PathVariable String id)
    {
		employeeService.deleteEmployee(id);
    }
	
	@RequestMapping(method=RequestMethod.GET,value="/getemployee/{id}")
	public Employee getEmployee(String id)
	{
		return employeeService.getEmployeeById(id);
	}
	
}
