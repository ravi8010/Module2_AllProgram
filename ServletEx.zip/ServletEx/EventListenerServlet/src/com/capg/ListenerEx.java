package com.capg;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class ListenerEx
 *
 */
@WebListener
public class ListenerEx implements ServletContextListener {

    /**
     * Default constructor. 
     */
	
	
    public ListenerEx() {
        // TODO Auto-generated constructor stub
    	System.out.println("Listener example");
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    	System.out.println(" context distroyed ");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent event)  { 
         // TODO Auto-generated method stub
    	
    	ServletContext ctx=event.getServletContext();
    	
    	
    	String driverName=ctx.getInitParameter("DriverName");
    	String url=ctx.getInitParameter("url");
    	String userName=ctx.getInitParameter("username");
    	String password=ctx.getInitParameter("password");
    	try
    	{
    		Class.forName(driverName);
    		Connection con=DriverManager.getConnection(url, userName, password);
    		ctx.setAttribute("ravi", con);
    		
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	
    	System.out.println("Context Initialized");
    	
    	
    	
    	
    }
	
}
