package com.capgemini.server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloWorldEx
 */
@WebServlet("/HelloWorldEx")
public class AddSubMulDiv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddSubMulDiv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();	
		
		
		
		
		 String[] values=request.getParameterValues("habits");
	      out.println("Selected Values...");    
	        for(int i=0;i<values.length;i++)
	       {
	           out.println("<li>"+values[i]+"</li>");
	       }
	      
	/*
		String n1=request.getParameter("value1");
		int no1=Integer.parseInt(n1);
		
		String n2=request.getParameter("value2");
		int no2=Integer.parseInt(n2);
	
		String op=request.getParameter("op");
	
		if(op.equals("addition"))
		{
			out.println("Addtion is"+(no1+no2));
			
		}
		else if	(op.equals("sub"))
		{
			out.println("Addtion is"+(no1-no2));
			
		}
		else if(op.equals("mul"))
		{
			out.println("Addtion is"+(no1*no2));
			
		}
		else if(op.equals("div"))
		{
			out.println("Addtion is"+(no1/no2));
			
		}
		else
		{
			out.println("no option is selected");
		}*/
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
